package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
@RestController
class ServerController{
	
public static String hashCalculation(String name) throws NoSuchAlgorithmException {
    MessageDigest md = MessageDigest.getInstance("SHA-256");  
    md.update(name.getBytes());
    byte[] hash = md.digest();    
    StringBuffer hexString = new StringBuffer();
    for (int i = 0;i<hash.length;i++) {
        hexString.append(Integer.toHexString(0xFF & hash[i]));
}
    return hexString.toString();
}
//FIXME:  Add hash function to return the checksum value for the data string that should contain your name.    
    @RequestMapping("/hash")
    public String myHash() throws NoSuchAlgorithmException{
       String data = "Joseph Thomas \r\n";
       String hash = hashCalculation(data);
       return "<p>data:"+data+"Name of Cipher Algorithm Used : CheckSum SHA-256 "+" Value : "+hash;
    }
}